import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import re
from sklearn.linear_model import LogisticRegression
from sklearn.kernel_approximation import RBFSampler
from sklearn.pipeline import make_pipeline
from scipy.cluster.vq import kmeans, vq
import seaborn as sns
sns.set_style("whitegrid")

#Per i colori dei plot
def get_cmap(n, name='viridis'):
    '''Returns a function that maps each index in 0, 1, ..., n-1 to a distinct 
    RGB color; the keyword argument name must be a standard mpl colormap name.'''
    return plt.cm.get_cmap(name, n)

def custom_parse_data(X, y):
	res_x, res_y =[], []
	for i in range(len(X)):
		string = X[i]
		new_string = re.sub(r'\s+', ',', string)
		string_list = list(new_string)
		string_list[1] = ''
		new_string = ''.join(string_list)
		res_x.append(np.fromstring(new_string.strip('[]'), dtype=float, sep=','))

	for i in range(len(y)):
		res_y.append(np.fromstring(y[i].strip('[]'), dtype=int, sep=' '))

	return np.array(res_x), np.array(res_y)


def BoF(X, codebook=None, k=None, normalize=True, plot=False):
	'''
	Bag of Features (Bag of Visual Words)

	Input:
		X: numpy array NxM
		codebook: None if training, the "learnt" codebook otherwise
		k: number of cluseters for k-means. Determines the dimensionality of resulting data
		normalize: if True applies TF-IDF normalization
		plot: if True plots the k-means clustering result

	Returns:
		result: The BoF features as a numpy array (Nxk)
		codebook: The learnt codebook
	'''

	descriptors = X.reshape(-1, 6, 3)
	all_descriptors = X.reshape(-1,3)

	if codebook is None:
		#Building the Codebook
		iters = 50
		if k == None:
			dists = []
			min_dist = 1e10
			for kk in range(2,50):
				cb, variance = kmeans(all_descriptors, kk, iters, seed=123)
				dists.append(variance)
				if variance < min_dist:
					min_dist = variance
					codebook = cb
			plt.plot(np.arange(2,50), dists, '--o')
			plt.grid()
			plt.show()
		else:
			codebook, _ = kmeans(all_descriptors, k, iters)

	#Vector quantization
	visual_words = []
	for i in range(descriptors.shape[0]):
		img_descriptors = descriptors[i,:,:]
		# for each image, map each descriptor to the nearest codebook entry
		img_visual_words, distance = vq(img_descriptors, codebook)
		visual_words.append(img_visual_words)

	if plot:
		vw = np.hstack(visual_words)[:2000]
		cmap = get_cmap(len(np.unique(vw)))
		fig = plt.figure()
		ax = fig.add_subplot(projection='3d')
		for i in range(len(vw)):
			ax.scatter(all_descriptors[i,0], all_descriptors[i,1], all_descriptors[i,2], color=cmap(vw[i]))
		plt.show()

	#Frequency count
	frequency_vectors = []
	for img_visual_words in visual_words:
	    # create a frequency vector for each image
	    img_frequency_vector = np.zeros(k)
	    for word in img_visual_words:
	        img_frequency_vector[word] += 1
	    frequency_vectors.append(img_frequency_vector)
	# stack together in numpy array
	frequency_vectors = np.stack(frequency_vectors)

	if normalize:
		#tf-idf
		N = descriptors.shape[0] 	# N is the number of images, i.e. the size of the dataset
		# df is the number of images that a visual word appears in
		# we calculate it by counting non-zero values as 1 and summing
		df = np.sum(frequency_vectors > 0, axis=0) + 1e-10
		idf = np.log(N/df)
		result = frequency_vectors * idf
	else:
		result = frequency_vectors

	return result, codebook



#------------------------------------- MAIN ---------------------------------------------

#Load data
data = pd.read_csv("output_CB_library.csv")
#transform to numpy
X, y = custom_parse_data(data.X.values, data.y.values)

#shift
y = y[1:]
X = X[:-1,:]
yn = np.argmax(y, axis=1)

#Number fo clusters
k = 25

#Train test split
test_size = int(X.shape[0] * 0.3)
X_train = X[:test_size,:]
X_test = X[test_size:,:]
y_train = yn[:test_size]
y_test = yn[test_size:]

X_train_bof, codebook = BoF(X_train, codebook=None, k=k, normalize=True)	#train the BoF model
X_test_bof, _ = BoF(X_test, codebook=codebook, k=k, normalize=True)			#transform the test set

#Classification pipeline
pipe = make_pipeline(RBFSampler(gamma=1., n_components=200),
                     LogisticRegression(multi_class='multinomial', solver='lbfgs', max_iter=10000))

#pipe = make_pipeline(LogisticRegression(multi_class='multinomial', solver='lbfgs', max_iter=10000))
pipe.fit(X_train_bof, y_train)
preds = pipe.predict(X_test_bof)

accuracy = np.sum(preds == y_test) / X_test_bof.shape[0]

print("\nK = "+ str(k) + " - Test Accuracy: " + str(accuracy))
print(" ")

#Plot distribution of labels and predictions
xx = [0,1,2,3,4,5]
labels = ['CB', 'STS', 'STS', 'Speaker', 'Non Speaker', 'Non Speaker']
plt.figure()
plt.hist(y_test)
plt.xticks(xx, labels, rotation=45)
plt.title('Real')

plt.figure()
plt.hist(preds)
plt.title('Predicted')
plt.xticks(xx, labels, rotation=45)
plt.show()

'''pipe = make_pipeline(RBFSampler(),
                     LogisticRegression(multi_class='multinomial', solver='lbfgs', max_iter=10000))

param_range = [0.1, 1.]
#param_range = [0.1]
ncomp = [500]

param_grid = [{'rbfsampler__gamma': param_range, 
               'rbfsampler__n_components': ncomp}]

gs = GridSearchCV(estimator=pipe, 
                  param_grid=param_grid, 
                  scoring='balanced_accuracy', 
                  refit=True,
                  cv=10,
                  n_jobs=-1)

gs = gs.fit(X_train_bof, y_train)
print(' ')
print(gs.best_score_)
print(gs.best_params_)

clf = gs.best_estimator_
preds = clf.predict(X_test_bof)

accuracy = np.sum(preds == y_test) / X_test_bof.shape[0]
accuracies.append(accuracy)

print("K = "+ str(k) + " - Test Accuracy: " + str(accuracy))'''
#print(' ')

'''plt.plot(np.arange(3,50), accuracies, '--o')
plt.grid()
plt.show()'''

#import code; code.interact(local=locals())
